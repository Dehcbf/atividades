/*Meu primeiro programa
Autora: Débora*/
var a = 2;
var b = 3;
var soma = a+b;
var sub = a-b;
var mul = a*b;
var div = a/b;

alert (soma);
alert (sub);
alert (mul);
alert (div);