/*Meu primeiro programa
Autora: Débora*/

alert ("Ola");