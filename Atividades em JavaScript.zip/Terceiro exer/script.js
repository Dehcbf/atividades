/*Meu primeiro programa
Autora: Débora*/
var mensagem = "Olá mundo!";
alert (mensagem);