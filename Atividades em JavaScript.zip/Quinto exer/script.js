/*Meu primeiro programa
Condicionais
Autora: Débora*/
var a = 2;
var b = 3;
var soma = a+b;
var sub = a-b;
var mul = a*b;
var div = a/b;

if (b%2 == 1){ //Caso tenha === é mesmo valor E mesmo tipo 
	alert("Número ímpar");
}
